document.getElementById('contact_form').addEventListener('submit', function(event) {
    const firstname = document.getElementById('firstname').value;
    const lastname = document.getElementById('lastname').value;
    const email = document.getElementById('email').value;
    const message = document.getElementById('message').value;

    alert("Thanks " + firstname + " " + lastname + "! The operation has been successful.");
});