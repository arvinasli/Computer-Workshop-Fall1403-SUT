<?php
    // Arvin Baghal Asl
    $username = $_POST["username"];
    $password = $_POST["password"];

    if(strlen($username)<6 && strlen($password)<8) {
        echo "Your username & password are incorrect!!";
    }
    else if(strlen($username)<6) {
        echo "Your username is incorrect!";
    }
    else if (strlen($password) < 8) {
        echo "Your password is incorrect!";
    }
    else {
        echo "Welcome $username!";
    }
?>