<?php
    // Arvin Baghal Asl
    $num1 = $_GET["num1"];
    $operation = $_GET["operation"];
    $num2 = $_GET["num2"];

    if($operation == "+") {
        $result = $num1+$num2;
        echo "Result: $num1 + $num2 = $result";
    }
    if($operation == "-") {
        $result = $num1-$num2;
        echo "Result: $num1 - $num2 = $result";
    }
    if($operation == "*") {
        $result = $num1*$num2;
        echo "Result: $num1 * $num2 = $result";
    }
    if($operation == "/") {
        $result = $num1/$num2;
        echo "Result: $num1 / $num2 = $result";
    }
    if($operation == "%") {
        $result = $num1%$num2;
        echo "Result: $num1 % $num2 = $result";
    }
?>